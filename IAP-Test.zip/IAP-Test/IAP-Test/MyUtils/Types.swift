//
//  Types.swift
//  IAP-Test
//
//  Created by Thanh Hoang on 12/07/2022.
//

import UIKit

let appDL = UIApplication.shared.delegate as! AppDelegate
let sceneDL = UIApplication.shared.connectedScenes.first!.delegate as! SceneDelegate

let screenWidth = UIScreen.main.bounds.size.width
let screenHeight = UIScreen.main.bounds.size.height
