//
//  AdmobUtils.swift
//  IAP-Test
//
//  Created by Thanh Hoang on 12/07/2022.
//

import UIKit
import GoogleMobileAds

class AdmobUtils: NSObject {
    
    static let shared = AdmobUtils()
    
    //MARK: - Admob Ads ID
    public let bannerAdID = "ca-app-pub-3940256099942544/2934735716" //Test
    
    private var iapHelperNotifObs: Any?
}

//MARK: - BannerView

extension AdmobUtils {
    
    func createBannerView(vc: UIViewController, completion: @escaping (GADBannerView?) -> Void) {
        let size = GADAdSizeFromCGSize(CGSize(width: screenWidth, height: 50.0))
        let bannerView = GADBannerView(adSize: size)
        bannerView.adUnitID = bannerAdID
        bannerView.rootViewController = vc
        bannerView.load(GADRequest())
        
        addBannerViewToUIView(bannerView, vc: vc)
        
        completion(bannerView)
    }
    
    ///BannerView For UIView
    private func addBannerViewToUIView(_ bannerView: GADBannerView, vc: UIViewController) {
        let bannerW: CGFloat = bannerView.frame.width
        let bannerH: CGFloat = bannerView.frame.height
        
        vc.view.addSubview(bannerView)
        bannerView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            bannerView.widthAnchor.constraint(equalToConstant: bannerW),
            bannerView.heightAnchor.constraint(equalToConstant: bannerH),
            bannerView.bottomAnchor.constraint(equalTo: vc.view.safeAreaLayoutGuide.bottomAnchor),
            bannerView.centerXAnchor.constraint(equalTo: vc.view.centerXAnchor),
        ])
    }
}
