//
//  ViewController.swift
//  IAP-Test
//
//  Created by Thanh Hoang on 12/07/2022.
//

import UIKit
import GoogleMobileAds
import PDFKit

class ViewController: UIViewController {
    
    //MARK: - Admob
    var bannerView: GADBannerView!
    
    //MARK: - UIView
    private let pdfView = PDFView()
    
    //MARK: - Properties
    
    //MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupsView()
        setupNavi()
        
        AdmobUtils.shared.createBannerView(vc: self) { ad in
            self.bannerView = ad
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadData()
    }
}

//MARK: - SetupView

extension ViewController {
    
    private func setupsView() {
        navigationItem.title = "Harry Potter"
        
        //TODO: - PDFView
        view.addSubview(pdfView)
        pdfView.translatesAutoresizingMaskIntoConstraints = false
        
        //TODO: - NSLayoutConstraint
        NSLayoutConstraint.activate([
            pdfView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            pdfView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            pdfView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            pdfView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
    }
    
    private func setupNavi() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Remove Ads", style: .plain, target: self, action: #selector(removeAdsDidTap))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Restore", style: .plain, target: self, action: #selector(restoreDidTap))
    }
    
    @objc private func removeAdsDidTap() {
        print("removeAdsDidTap")
    }
    
    @objc private func restoreDidTap() {
        print("restoreDidTap")
    }
}

//MARK: - Data

extension ViewController {
    
    private func loadData() {
        if let path = Bundle.main.path(forResource: "HarryPotter.pdf", ofType: nil),
            let file = PDFDocument(url: URL(fileURLWithPath: path)) {
            pdfView.displayMode = .singlePageContinuous
            pdfView.autoScales = true
            pdfView.displayDirection = .vertical
            pdfView.document = file
        }
    }
}
